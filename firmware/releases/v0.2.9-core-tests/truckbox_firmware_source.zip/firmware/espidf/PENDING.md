Core 0.2.9 (TESTES): correção de acesso ao barramento J1708 e modo de viagem.
Leia [J1708_FIX_v0.2.9.md](J1708_FIX_v0.2.9.md) e [ACTIVE_J1708.md](ACTIVE_J1708.md).
Somente Core; teste elétrico/estacionado pendente, Link e microSD sem alteração.

# Pendências da v0.2.3 de testes

O diagnóstico físico da 0.2.2 confirmou J1708 e o bloqueio do endereço do Link;
PEER_FIX_v0.2.3.md documenta a correção e os testes reais de sockets locais.
Ainda falta confirmar Core → Link → Cloud na placa após esta atualização.

1. **Hardware real não acessível:** inicialização, recepção de duas redes, microSD real sem GPS, vazão/perda em carga, quedas de alimentação, reboot e recuperação/OTA precisam ser ensaiados na placa. Testes host com falhas simuladas não substituem esses ensaios.
2. **J1939:**55/76 itens decodificados;15 brutos/parciais e6 sem valor físico seguro, detalhados por ID na cobertura. Não inventar máscaras ABS/estacionamento, demanda/starter, top gear ou escalas proprietárias. Campos já interpretados parcialmente conservam EM_VALIDACAO. Validação física não é inferida da compilação.
3. **Logs Mãe:** referências históricas recuperadas, mas ZIPs originais ausentes. Equivalência Python/C e fixtures do Mestre executados; estatísticas históricas e replay completo não repetidos.
4. **Transporte:** receptor TP.BAM limitado a4sessões/64bytes/1250ms. RTS/CTS não remontado; frames permanecem brutos. Confirmar transporte real das configurações da ECU.
5. **J1708 ativo:** todos17 implementados e testados por callbacks. Confirmar waveform, nível recessivo, eco, arbitragem e aborto no barramento real. Definir MID local livre e os17MIDs-alvo por evidência; nenhum está presumido no binário. Todas leituras experimentais. Teste só autorizado, estacionado e com lease60s.
6. **Cloud:** ingest v26 implantada; corrige milissegundos fracionários rejeitados por bigint. Envio real Core → Link → Wi-Fi → Cloud confirmado para a fila persistida, incluindo RAW/DECODED CAN/J1708 e OPERATIONAL. Ainda pendentes vazão sustentada, perdas com flash limitada, reconexão e comprovação de coleta atual nas duas redes. Consulte cloud/UPTIME_FIX_v26.md.
7. **Capacidade/vazão:** fila RX128frames e store64registros; fsync por registro. SD128segmentos de1MiB ou flash24segmentos de48KiB. Ao esgotar espaço retém backlog e rejeita novas entradas com contadores. Não há promessa de captura ilimitada ou sem perdas em qualquer carga. Fila RAM não é persistência; só registros confirmados são oferecidos para ACK.
8. **Contadores:** checkpoints de viagem em NVS a cada30s; falha antes do checkpoint pode perder a parcela ainda não confirmada dos totais de sessão, mas não remove o log já fsync. Reboot/lacuna/reset de contador reestabelece marco, sem inventar distância durante tempo desconhecido. Estimativa por velocidade e combustível derivado têm origem explícita. Histórico de combustível da v0.1.0 é preservado, podendo conter modelo anterior; o modelo atual não reescreve esse histórico.
9. **Montagem:** HARDWARE.md registra defeitos e medições herdados da base. O estado atual desses reparos não foi aferido nesta sessão. Não dirigir GPIO1/watchdog nem gates16/17 sem comissionamento comprovado. SD exige sd_enabled e repaired_power_gates; sem isso há fallback e diagnóstico, não confirmação de microSD.
10. **Entrega local do cliente:** o diretório /codex/browser/projectless/.../output não existe neste executor e sua raiz é somente leitura. Não foi possível exportar para esse caminho; fontes e pacote são disponibilizados na branch GitHub de testes.
