@echo off
cd /d "%~dp0"
if "%~1"=="" (
  echo Uso: flash_core.cmd COM3
  pause
  exit /b 2
)
py "%~dp0tools\flash_device.py" --role core --port "%~1"
set TB_FLASH_RESULT=%ERRORLEVEL%
pause
exit /b %TB_FLASH_RESULT%
