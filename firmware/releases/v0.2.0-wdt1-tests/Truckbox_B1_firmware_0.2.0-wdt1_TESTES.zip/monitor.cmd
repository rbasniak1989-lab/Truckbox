@echo off
cd /d "%~dp0"
if "%~1"=="" (
  echo Uso: monitor.cmd COM3
  pause
  exit /b 2
)
py "%~dp0tools\monitor_device.py" "%~1"
