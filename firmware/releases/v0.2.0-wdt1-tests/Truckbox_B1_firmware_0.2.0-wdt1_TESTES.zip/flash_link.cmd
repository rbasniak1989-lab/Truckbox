@echo off
cd /d "%~dp0"
if "%~1"=="" (
  echo Uso: flash_link.cmd COM3
  pause
  exit /b 2
)
py "%~dp0tools\flash_device.py" --role link --port "%~1"
set TB_FLASH_RESULT=%ERRORLEVEL%
pause
exit /b %TB_FLASH_RESULT%
