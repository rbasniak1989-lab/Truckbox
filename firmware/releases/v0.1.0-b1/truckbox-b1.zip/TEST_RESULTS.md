# Verificação da versão 0.1.0-b1

Verificação executada em 5 de novembro de 2026.

## Compilação

- Core e Link compilados para ESP32-C6 com ESP-IDF v5.5.2 e GCC RISC-V 14.2.0.
- Flash configurada em 8 MB; ambas as aplicações cabem nos slots OTA de 3 MiB.
- Console USB Serial/JTAG; console UART0 de aplicação desativado e logs do bootloader desativados.
- Interrupções UART e CAN/TWAI em IRAM para manter a recepção durante operações de flash.
- Nomes de projeto diferentes, truckbox_core e truckbox_link, para validação da função nas atualizações.

## Testes automatizados

- Configuração e NVS com valores inválidos, atualização parcial, limites, geração e preservação de credenciais; Core e Link.
- Política de imagem OTA: função errada, chip errado, tamanho de flash errado, truncamento, cabeçalhos e hash ausente.
- Protocolos CAN/J1939 e J1708/J1587; 4.000 registros aleatórios verificados por um parser JSON independente.
- Integridade de registros, CRC e cauda interrompida.
- Codec FRAM, corrupções, gerações, interrupções e proteção do ACK após reset de NVS.
- NMEA com checksum e dados inválidos; fila GPS com repetição conservadora e recuperação.
- Seis testes do instalador: pacote íntegro, tamanho de flash errado, arquivo corrompido, função trocada, região NVS e caminho fora do pacote.
- Quinze cenários no Chromium/Playwright contra servidor local simulado: login, permissões, omissão de segredos, configuração parcial, vínculo, upload, encaminhamento, erros, logout e tela móvel.
- Testes C executados com AddressSanitizer e UndefinedBehaviorSanitizer; LeakSanitizer desativado pela incompatibilidade com ptrace neste ambiente.

Reprodução dos testes C/Python: IDF_PATH=<SDK> sh tests/run_all.sh. O teste de navegador está em tests/web/.

## Limites da evidência

Os testes de navegador usam dados explicitamente simulados e não escrevem no Supabase ou em uma PCB. O contrato foi conferido nas funções existentes truckbox-ingest e truckbox-gps, sem alterar o servidor.

Continuam pendentes os testes físicos de primeira partida, estabilidade de EN/alimentações, Wi-Fi, atualização OTA com interrupção de energia, rollback real, CAN/J1708 no veículo, GPS, microSD/FRAM, SIM e LTE. A resposta do bootloader USB obtida antes desta compilação não equivale a esses testes. Consulte HARDWARE.md.
