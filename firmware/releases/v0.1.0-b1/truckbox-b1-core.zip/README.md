# Pacote reduzido: somente Core

Este ZIP contém a primeira instalação e a imagem OTA do Core. O firmware Link e as fontes estão no pacote completo.

# Truckbox Rev B1 — firmware Core e Link

Firmware inicial para dois ESP32-C6-WROOM-1 com **8 MB de flash**. O Core conecta ao Wi‑Fi de 2,4 GHz do celular ou roteador e oferece uma página local para configuração, diagnóstico e atualização dos dois módulos.

Esta versão inclui os módulos de coleta e comunicação. CAN, J1708, GPS, modem, microSD, FRAM e OTA precisam ser validados fisicamente na placa. Os problemas conhecidos da B1 estão em [HARDWARE.md](HARDWARE.md); o firmware não corrige essas ligações.

## Funções

| Core | Link |
|---|---|
| CAN clássico em listen-only, 250 ou 500 kbit/s | GPS NMEA |
| J1708/J1587, checksum e diagnóstico de enquadramento | Modem A7638E por UART e PPP |
| Decodificação inicial de rotação, velocidade, odômetro e vazão | Envio HTTPS para a API existente |
| Amostras operacionais a 1 Hz com medições válidas e recentes | Fila persistente de pontos GPS |
| Registros de saúde por minuto | Fix recente enviado ao Core a 1 Hz |
| Fila persistente, microSD e journal FRAM opcionais | Página própria de diagnóstico e OTA |
| API e stream TCP compatíveis com o Android | OTA também pela página do Core |

O enlace interno Core–Link usa Wi‑Fi e libera as duas UARTs do Link para GPS e modem. A rede interna não fornece Internet ao Link: seu envio direto à nuvem usa LTE. O aplicativo Android pode continuar atuando como gateway pela API do Core.

## Primeira instalação do Core no Windows

Extraia o ZIP em uma pasta. O pacote inclui `manifest.json`, `images/`, scripts `.cmd` e arquivos `*_ota.bin`. Não execute de dentro do ZIP.

1. Confira [HARDWARE.md](HARDWARE.md), principalmente alimentação e EN.
2. Alimente pela fonte da placa. Mantenha o +5 V do cabo USB desconectado e isolado; confira GND, D+ e D−.
3. Para o gravador, mantenha BOOT/GPIO9 no GND e GPIO8 alto durante a partida, como no arranjo já testado.
4. Feche monitores seriais que estejam usando a COM3.
5. Abra o Prompt na pasta extraída e execute:

```bat
flash_core.cmd COM3
```

O script verifica hashes, consulta o chip e exige flash de 8 MB. Grava bootloader, tabela, dados iniciais de OTA e aplicação. Preserva NVS e registros; reinicializa os dados de seleção de boot OTA. Use-o para instalação/manutenção USB, não para a atualização habitual.

Após a gravação:

1. Desconecte o USB e desligue a fonte.
2. Retire **somente o jumper BOOT/GPIO9–GND**. Mantenha o resistor de 10 kΩ do GPIO8 para 3,3 V.
3. Ligue a fonte e reconecte o USB.
4. Execute:

```bat
monitor.cmd COM3
```

Digite `setup` e pressione Enter. O console mostra:

- `AP`: nome da rede de configuração;
- `AP password`: senha dessa rede;
- `AP URL`: endereço da página;
- `Admin key`: chave de administração da página.

Guarde essas credenciais localmente. São geradas na placa e persistidas em NVS. O comando `setup` permite consultá-las pelo USB; `status` mostra o diagnóstico; `restart` reinicia. Saia do monitor com **Ctrl + ]**.

Os scripts requerem Python e esptool 5.x. Se necessário:

```bat
py -m pip install "esptool>=5,<6"
```

## Conectar o Core ao celular ou roteador

1. Conecte o notebook à rede `Truckbox-Core-XXXX`, usando a senha do `setup`. Ela pode aparecer como rede sem Internet.
2. Abra **http://192.168.4.1/**.
3. Digite a `Admin key` em **Acesso de administração**.
4. Em **Wi‑Fi do celular ou roteador**, informe SSID e senha da rede de **2,4 GHz**.
5. Salve e aguarde o reinício.
6. Reconecte o notebook à mesma rede do celular/roteador e abra **http://truckbox.local/**.

Se o nome `.local` não resolver, use o IP LAN mostrado no USB/diagnóstico. O AP interno continua disponível em `192.168.4.1`.

A LAN do roteador não pode usar **192.168.4.0/24**, faixa da rede interna. O diagnóstico `subnet_conflict` informa sobreposição. Alguns hotspots e redes de convidados isolam os clientes: ajuste o isolamento ou acesse diretamente o AP do Core.

## Instalar e vincular o Link

O Link também precisa da primeira imagem USB. Antes, confira `3V3_LINK` e os requisitos de BOOT em [HARDWARE.md](HARDWARE.md). Use seu USB-C e identifique a COM; não presuma que seja a COM3 do Core.

```bat
flash_link.cmd COM4
```

Substitua `COM4` pela porta identificada. Faça a sequência de desligamento, retirada do jumper BOOT e reinício descrita para o Core. Abra o monitor nessa COM e digite `setup`.

1. Na página do Core, entre com a chave de administração e consulte **Vínculo Core e Link**.
2. Conecte à rede `Truckbox-Link-XXXX`, com a senha do `setup` do Link.
3. Abra **http://192.168.5.1/** e use a chave de administração do **Link**.
4. Em **Ligação interna com o Core**, copie para os três campos o SSID, a senha da rede interna e a chave de vínculo obtidos no Core.
5. Salve e aguarde o reinício.

O Link usará `192.168.4.2` na rede interna. Após o vínculo, suas atualizações podem ser enviadas pela página do Core, sem reconectar USB.

## Nuvem, GPS e operadora

Os endereços iniciais são os já usados pelo aplicativo:

- Telemetria: `https://wbzrrjufhqfgoctxtlyi.supabase.co/functions/v1/truckbox-ingest`
- GPS: `https://wbzrrjufhqfgoctxtlyi.supabase.co/functions/v1/truckbox-gps`

Cadastre o identificador de ingestão do Core e os tokens individuais. O GPS pode usar UID e token diferentes. **Não use `service_role`, chave administrativa do Supabase nem senha da conta.**

No Link, configure a APN e, se exigidos, usuário e senha da APN. Ative o modem após conferir SIM, antenas e alimentação. Falhas de SIM, APN, sinal ou fix GPS aparecem no diagnóstico e não devem impedir o painel.

HTTPS verifica certificados e precisa de relógio válido, obtido por SNTP e/ou GPS. Campos desconhecidos de veículo/GPS são omitidos do envio para evitar zeros que representariam medições inexistentes.

Ao reutilizar um UID com dados na nuvem, configure `sequence_floor` como **o primeiro número livre, maior que qualquer sequência já usada**. Não mantenha dois equipamentos gerando sequências para o mesmo UID. Preservar NVS mantém o contador; apagar NVS exige planejar novamente essa migração.

## Armazenamento e limites

- Core: fila em flash de **1,125 MiB**; com microSD habilitado e alimentação corrigida, limite de **128 MiB**.
- FRAM: journal espelhado de metadados; não substitui cartão nem amplia a fila.
- Link: fila GPS de **768 KiB**, com captura persistente a cada **5 segundos**. O fix recente vai ao Core a 1 Hz.
- Dados são liberados após ACK válido. Fila cheia/indisponível gera contadores de descarte; a capacidade é finita.
- Registros CRC inválidos, mídia desconhecida e troca de cartão com backlog não provocam formatação automática. A flash só é inicializada automaticamente quando toda a partição está apagada.
- Um corte de energia pode perder dados ainda em RAM. Reservas de sequência e ACKs duráveis evitam reutilização de sequência e descarte sem confirmação.

microSD, FRAM, modem e confirmação do reparo das chaves começam desabilitados. CAN/J1708 e leitura GPS começam habilitados. Marque **Acionamento de alimentação corrigido** somente após o retrabalho e as medições.

CAN recebe apenas quadros clássicos: esta PCB não liga TXD ao MCU. O TCP `35000` transmite os quadros CAN. O enquadramento J1708 usa timeout de um caractere e checksum; valide sua taxa de erros no barramento real.

## Atualização e desenvolvimento

[OTA.md](OTA.md) descreve atualização por Wi‑Fi e recuperação. Ambos os módulos precisam receber a primeira instalação USB.

Fontes para ESP-IDF **v5.5.2**, alvo `esp32c6`. Com o SDK ativado:

```sh
idf.py -B build-core -DTRUCKBOX_ROLE=core build
idf.py -B build-link -DTRUCKBOX_ROLE=link build
python tools/build_release.py
```

Para uma versão futura, use o mesmo `PROJECT_VER` nos dois builds, por exemplo `-DPROJECT_VER=0.1.1-b1`. Preserve o protocolo entre módulos e a compatibilidade da NVS.

Os testes em `components/*/tests` cobrem parsers, registros, configuração e política de imagem OTA. Compilação e testes automatizados não substituem validação física de alimentação, rádio, barramentos, mídias, SIM e interrupção de energia durante OTA. Esta é uma versão inicial para comissionamento, não homologada para operação definitiva.
